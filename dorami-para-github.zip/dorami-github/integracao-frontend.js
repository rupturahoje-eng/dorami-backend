/*
  Como ligar o botão "Confirmar assinatura" do dorami-completo.html ao servidor.

  1) Troque a URL abaixo pelo endereço do seu servidor publicado
     (ex: https://dorami-backend.onrender.com) — enquanto testa local, deixe
     como http://localhost:3333

  2) No arquivo dorami-completo.html, troque o botão:
       <button class="btn btn-primary btn-full">Confirmar assinatura</button>
     por:
       <button class="btn btn-primary btn-full" onclick="confirmarAssinatura()">Confirmar assinatura</button>

  3) Cole o código abaixo dentro da tag <script> do dorami-completo.html.
*/

const URL_DO_SERVIDOR = 'http://localhost:3333'; // troque depois de publicar o backend

async function confirmarAssinatura() {
  const planoSelecionado = document.querySelector('.checkout-plan.selected').dataset.plan;

  try {
    const resposta = await fetch(`${URL_DO_SERVIDOR}/criar-assinatura`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plano: planoSelecionado }),
    });

    const dados = await resposta.json();

    if (dados.link_pagamento) {
      // Manda o usuário para o checkout seguro do Mercado Pago
      window.location.href = dados.link_pagamento;
    } else {
      alert('Não foi possível iniciar o pagamento. Tente novamente em instantes.');
    }
  } catch (erro) {
    console.error(erro);
    alert('Erro de conexão com o servidor de pagamento.');
  }
}
