// Servidor do Dorami — cria cobranças no Mercado Pago (Checkout Pro)
// -------------------------------------------------------------------
// Como usar:
// 1) npm install
// 2) copie .env.example para .env e cole seu Access Token de produção
// 3) npm start
// 4) o servidor sobe em http://localhost:3333
//
// No front-end (dorami-completo.html), o botão "Confirmar assinatura"
// deve chamar POST /criar-assinatura em vez de só fechar a tela.
// Veja o arquivo integracao-frontend.js para o trecho pronto.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { MercadoPagoConfig, Preference } = require('mercadopago');

const app = express();
app.use(cors());
app.use(express.json());

if (!process.env.MP_ACCESS_TOKEN || process.env.MP_ACCESS_TOKEN.includes('COLE_SEU')) {
  console.warn('\n⚠️  Atenção: MP_ACCESS_TOKEN não foi configurado no .env — as cobranças vão falhar até você preencher isso.\n');
}

const client = new MercadoPagoConfig({ accessToken: process.env.MP_ACCESS_TOKEN || '' });

// Os 3 planos do Dorami — mantenha esses valores como única fonte da verdade,
// nunca confie em preço enviado pelo navegador do usuário.
const PLANOS = {
  mensal:     { titulo: 'Dorami — Plano Mensal (1 mês)',   preco: 7  },
  bimestral:  { titulo: 'Dorami — Plano 2 meses',          preco: 12 },
  trimestral: { titulo: 'Dorami — Plano 3 meses',          preco: 18 },
};

app.get('/', (req, res) => {
  res.send('Servidor Dorami no ar. Use POST /criar-assinatura para gerar uma cobrança.');
});

app.post('/criar-assinatura', async (req, res) => {
  try {
    const { plano } = req.body;
    const dados = PLANOS[plano];

    if (!dados) {
      return res.status(400).json({ erro: 'Plano inválido. Use: mensal, bimestral ou trimestral.' });
    }

    const siteUrl = process.env.SITE_URL || 'http://localhost:5500';

    const preference = new Preference(client);
    const resultado = await preference.create({
      body: {
        items: [
          {
            title: dados.titulo,
            quantity: 1,
            unit_price: dados.preco,
            currency_id: 'BRL',
          },
        ],
        back_urls: {
          success: `${siteUrl}/sucesso.html`,
          failure: `${siteUrl}/falha.html`,
          pending: `${siteUrl}/pendente.html`,
        },
        auto_return: 'approved',
        statement_descriptor: 'DORAMI',
      },
    });

    // init_point = link do checkout do Mercado Pago para redirecionar o usuário
    res.json({ link_pagamento: resultado.init_point });
  } catch (err) {
    console.error(err);
    res.status(500).json({ erro: 'Não foi possível criar a cobrança. Confira o MP_ACCESS_TOKEN no .env.' });
  }
});

const PORT = process.env.PORT || 3333;
app.listen(PORT, () => {
  console.log(`Servidor Dorami rodando em http://localhost:${PORT}`);
});
